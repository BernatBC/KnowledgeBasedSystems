PRÀCTICA 2 IA - Bernat Borràs Civil, Òscar Ramos Núñez, Alexandre Ros Roger

Per a executar, cal obrir Clips en aquest directori i fer:

(load "ontologiaKBS.clp")
(load "kbs.clp")
(reset)
(run)

A la Documentacio s'especifica en detall com funciona el nostre projecte.

Documentacio.pdf -> La documentació d'aquest projecte
kbs.clp -> Programa principal, no generat per Protégé
ontologiaKBS.clp -> Ontologia pel projecte, generat amb Protégé (i amb
owl2clp)
ontologiaKBS.owl -> Ontologia generada amb Protégé (turtle)
PrototipoInicialPracticaSBC.zip -> Zip del prototip inicial (punt extra)
